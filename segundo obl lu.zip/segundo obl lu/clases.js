class Jugador{
    constructor(Nombre,Edad){
        this.Nombre = Nombre;
        this.Edad = Edad;
    }
}

class Sistema {
  constructor() {
    this.listajugadores = [];          
    this.listacomentarios = [];       
 
  }

existeJugadordeNombre(Nombre) {
    let estaRepetido = false;
    let largo = this.listajugadores.length;
    for (let i = 0; i < largo; i = i + 1) {
        if (this.listajugadores[i].Nombre === Nombre) {
            estaRepetido = true;
        }
    }
    return estaRepetido;
}

agregarCarrera(carrera) {
  if (!this.existeCarreraDeNombre(carrera.Nombre)) {
    this.listacarreras.push(carrera);
    return "Carrera agregada";
  }
  return "Ya existe una carrera con ese nombre";
}
agregarCorredor(corredor) {
  let repetido = false;

  for (let i = 0; i < this.listacorredores.length; i++) {
    if (this.listacorredores[i].Cédula === corredor.Cédula) {
      repetido = true;
    }
  }

  if (repetido) {
    return "Ya existe un corredor con esa cédula.";
  } else if (corredor.Edad < 18) {
    return "El corredor debe tener al menos 18 años.";
  } else {
    let hoy = new Date();
    hoy.setHours(0, 0, 0, 0); 
      let fechaFicha = new Date(corredor.FechadeVencimientoFichaMedica);

    if (fechaFicha < hoy) {
      return "Ficha médica vencida.";
    }
    this.listacorredores.push(corredor);
    return "Corredor agregado correctamente.";
  }
}
}
