window.addEventListener("load",inicio);
const sistema = new Sistema();
function inicio(){
  document.getElementById("Datos").style.display ="block";
  document.getElementById("Juegos").style.display ="none"
  document.getElementById("Administrador").style.display ="none"
  document.getElementById("idDatos").addEventListener("click", mostrarDatos);
  document.getElementById("idJuegos").addEventListener("click", mostrarJuego);
  document.getElementById("idAdministrador").addEventListener("click", mostrarAdministrador);
  document.getElementById("idBotonAgregar").addEventListener("click", AgregarJugador);
  document.getElementById("idComentario").addEventListener("keydown", procesarComentario);
  document.getElementById("btn-corredor").addEventListener("click", agregarCorredor);
  document.getElementById("btn-inscribir").addEventListener("click", agregarinscripcion);
  document.getElementById("ordenNombre").addEventListener("change", actualizarConsulta);
  document.getElementById("ordenNumero").addEventListener("change", actualizarConsulta);

}

function mostrarDatos() {
    document.getElementById("Datos").style.display ="block";
    document.getElementById("Juegos").style.display ="none"
    document.getElementById("Administrador").style.display ="none"

}

function mostrarJuego() {
    if (sistema.listajugadores.length > 0) {
        document.getElementById("Datos").style.display ="none";
        document.getElementById("Juegos").style.display ="block";
        document.getElementById("Administrador").style.display ="none";
    } else {
        alert("Debe haber jugadores registrados.");
    }
}


function mostrarAdministrador() {
    document.getElementById("Datos").style.display ="none";
    document.getElementById("Juegos").style.display ="none"
    document.getElementById("Administrador").style.display ="block"

}

function ActualizarConsulta (){

}

function AgregarJugador() {

    let esValido = true;

    let Nombre = document.getElementById("idNombre").value;
    let Edad = Number(document.getElementById("idEdad").value);

    if (!document.getElementById("form-Ajugadores").reportValidity()) {
        esValido = false;
    }

    if (Nombre === "") {
        alert("Debe ingresar un nombre.");
        esValido = false;
    }

    if (Edad < 5 || Edad > 100) {
        alert("La edad debe estar entre 5 y 100.");
        esValido = false;
    }

    if (sistema.existeJugadordeNombre(Nombre) === true) {
        alert("Ese jugador ya existe.");
        esValido = false;
    }

    if (esValido === true) {
        let nuevoJugador = new Jugador(Nombre, Edad);
        sistema.listajugadores.push(nuevoJugador);
        alert("Jugador registrado con éxito.");

        ActualizarCombos();
    }

    return esValido;
}

